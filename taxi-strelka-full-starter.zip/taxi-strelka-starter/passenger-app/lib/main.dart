import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Android Emulator address. For a physical phone, configure a reachable API address.
const apiBase = String.fromEnvironment('API_BASE', defaultValue: 'http://10.0.2.2:3000');
void main() => runApp(const TaxiStrelkaApp());

class TaxiStrelkaApp extends StatelessWidget {
  const TaxiStrelkaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Такси Стрелка', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFFC928)), scaffoldBackgroundColor: const Color(0xFFF4F6F8), appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF121A29), foregroundColor: Colors.white)),
    home: const PassengerHome(),
  );
}
class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});
  @override State<PassengerHome> createState() => _PassengerHomeState();
}
class _PassengerHomeState extends State<PassengerHome> {
  final name = TextEditingController(), phone = TextEditingController(), pickup = TextEditingController(), destination = TextEditingController();
  bool loading = false, apiOnline = false, success = false;
  String message = '';
  @override void initState() { super.initState(); checkServer(); }
  @override void dispose() { name.dispose(); phone.dispose(); pickup.dispose(); destination.dispose(); super.dispose(); }
  Future<void> checkServer() async {
    try { final r = await http.get(Uri.parse('$apiBase/health')).timeout(const Duration(seconds: 4)); if (mounted) setState(() => apiOnline = r.statusCode == 200); }
    catch (_) { if (mounted) setState(() => apiOnline = false); }
  }
  Future<void> createRide() async {
    if ([name.text, phone.text, pickup.text, destination.text].any((s) => s.trim().isEmpty)) { setState(() { message = 'Заполни имя, телефон и оба адреса.'; success = false; }); return; }
    setState(() { loading = true; message = ''; success = false; });
    try {
      final r = await http.post(Uri.parse('$apiBase/api/rides'), headers: {'Content-Type':'application/json'}, body: jsonEncode({'settlementSlug':'strelka','passengerName':name.text.trim(),'passengerPhone':phone.text.trim(),'pickupAddress':pickup.text.trim(),'destinationAddress':destination.text.trim()})).timeout(const Duration(seconds: 12));
      final data = jsonDecode(r.body);
      if (r.statusCode == 201) { setState(() { message = 'Заказ №${data['id']} принят. Водитель пока не назначается автоматически.'; success = true; }); }
      else { setState(() { message = data is Map && data['error'] != null ? data['error'].toString() : 'Ошибка сервера ${r.statusCode}.'; }); }
    } catch (_) { setState(() { message = 'Нет связи с сервером. Проверь адрес API и подключение.'; }); }
    finally { if (mounted) setState(() => loading = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Такси Стрелка', style: TextStyle(fontWeight: FontWeight.w800)), Text('ПОСЁЛОК СТРЕЛКА • ЕНИСЕЙСКИЙ РАЙОН', style: TextStyle(fontSize: 10, color: Colors.white70))]), actions: [IconButton(onPressed: checkServer, icon: const Icon(Icons.sync))]),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFF121A29), Color(0xFF2B3A50)])), child: const Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Поехали?', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800)), SizedBox(height: 7), Text('Закажи поездку в пару касаний.', style: TextStyle(color: Colors.white70))])), Icon(Icons.local_taxi_rounded, color: Color(0xFFFFC928), size: 58)])),
      const SizedBox(height: 12), Row(children: [Icon(Icons.circle, size: 10, color: apiOnline ? Colors.green : Colors.orange), const SizedBox(width: 8), Text(apiOnline ? 'Сервер доступен' : 'Сервер пока недоступен', style: const TextStyle(fontSize: 12))]),
      const SizedBox(height: 18), const Text('Куда едем?', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)), const SizedBox(height: 12),
      field(name, 'Ваше имя', Icons.person_outline), const SizedBox(height: 10), field(phone, 'Номер телефона', Icons.phone_outlined, keyboard: TextInputType.phone), const SizedBox(height: 10), field(pickup, 'Адрес подачи', Icons.my_location, hint: 'Например: ул. Ленина, 1'), const SizedBox(height: 10), field(destination, 'Куда отвезти?', Icons.location_on_outlined),
      const SizedBox(height: 14), Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: const Row(children: [Icon(Icons.info_outline, size: 25), SizedBox(width: 10), Expanded(child: Text('Стоимость и время подачи пока не рассчитываются автоматически.', style: TextStyle(fontSize: 13)))])),
      const SizedBox(height: 16), SizedBox(height: 54, child: FilledButton(style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFFC928), foregroundColor: const Color(0xFF121A29), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))), onPressed: loading ? null : createRide, child: loading ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Заказать такси', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)))),
      if (message.isNotEmpty) ...[const SizedBox(height: 12), Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: success ? const Color(0xFFEAF8EF) : const Color(0xFFFFEEEE), borderRadius: BorderRadius.circular(14)), child: Text(message, style: TextStyle(color: success ? const Color(0xFF166534) : const Color(0xFFB91C1C))))],
      const SizedBox(height: 22), const Center(child: Text('Такси Стрелка • Стартовая версия', style: TextStyle(color: Colors.black45, fontSize: 12)))
    ])),
  );
  Widget field(TextEditingController c, String label, IconData icon, {String? hint, TextInputType keyboard = TextInputType.text}) => TextField(controller: c, keyboardType: keyboard, textCapitalization: TextCapitalization.sentences, decoration: InputDecoration(labelText: label, hintText: hint, prefixIcon: Icon(icon), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)));
}
