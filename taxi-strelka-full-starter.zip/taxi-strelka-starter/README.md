# Такси Стрелка — стартовый проект

В архиве три части: `passenger-app/` — Flutter-приложение пассажира; `backend/` — API Node.js + PostgreSQL; `admin/` — начальная веб-панель диспетчера.

Это стартовая основа, а не готовая коммерческая система. Пока отсутствуют полноценная карта/GPS, авторизация и роли, приложение водителя, платежи, push-уведомления и production-защита.

## Сборка APK через GitHub Actions
1. Загрузите содержимое архива в корень репозитория `taxi-strelka`, сохранив папки.
2. Откройте **Actions** → **Build Такси Стрелка APK** → **Run workflow**.
3. После успешной сборки откройте запуск и скачайте artifact `taxi-strelka-passenger-apk`.

## Запуск API
Нужны Docker и Docker Compose:
```bash
cd backend
docker compose up --build
```
Проверка: `http://localhost:3000/health`. Для физического телефона адрес API должен быть доступен с телефона; `10.0.2.2` работает в Android Emulator.

API: `GET /health`, `GET /api/settlements`, `GET /api/rides`, `POST /api/rides`, `PATCH /api/rides/:id/status`.
Перед реальным запуском необходимо добавить авторизацию, безопасность, резервные копии и мониторинг.
