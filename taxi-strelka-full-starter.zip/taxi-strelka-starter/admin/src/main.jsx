import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import './style.css';
const API=import.meta.env.VITE_API_BASE||'http://localhost:3000';
function App(){
 const [rides,setRides]=useState([]); const [status,setStatus]=useState('Загрузка заказов…');
 async function load(){try{const r=await fetch(`${API}/api/rides`);if(!r.ok)throw new Error();const data=await r.json();setRides(data);setStatus(`Заказов в списке: ${data.length}`)}catch{setStatus('API недоступен. Запустите backend и проверьте адрес API.')}}
 async function change(id,next){try{const r=await fetch(`${API}/api/rides/${id}/status`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:next})});if(!r.ok)throw new Error();await load()}catch{setStatus('Не удалось изменить статус заказа.')}}
 useEffect(()=>{load()},[]);
 return <main><header><div><div className="eyebrow">ДИСПЕТЧЕРСКАЯ</div><h1>Такси Стрелка</h1><p>Посёлок Стрелка · Енисейский район</p></div><button onClick={load}>Обновить</button></header>
 <section className="stats"><article><span>Заказы в списке</span><strong>{rides.length}</strong></article><article><span>Состояние API</span><strong className="small">{status}</strong></article></section>
 <section className="panel"><h2>Последние заказы</h2>{!rides.length?<p className="empty">Пока нет заказов. Подключите приложение пассажира к серверу.</p>:<div className="table-wrap"><table><thead><tr><th>№</th><th>Пассажир</th><th>Телефон</th><th>Откуда</th><th>Куда</th><th>Статус</th><th>Изменить</th></tr></thead><tbody>{rides.map(r=><tr key={r.id}><td>{r.id}</td><td>{r.passengerName}</td><td>{r.passengerPhone}</td><td>{r.pickupAddress}</td><td>{r.destinationAddress}</td><td><span className="pill">{r.status}</span></td><td><select value={r.status} onChange={e=>change(r.id,e.target.value)}><option value="new">Новый</option><option value="accepted">Принят</option><option value="arrived">На месте</option><option value="in_progress">В поездке</option><option value="completed">Завершён</option><option value="cancelled">Отменён</option></select></td></tr>)}</tbody></table></div>}</section><p className="foot">Стартовая панель без авторизации. Не размещайте публично до добавления защиты.</p></main>
}
createRoot(document.getElementById('root')).render(<App/>);
