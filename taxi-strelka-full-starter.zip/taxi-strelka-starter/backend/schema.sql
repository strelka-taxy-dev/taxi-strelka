CREATE TABLE IF NOT EXISTS settlements (id SERIAL PRIMARY KEY, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS rides (
 id BIGSERIAL PRIMARY KEY,
 settlement_id INTEGER NOT NULL REFERENCES settlements(id),
 passenger_name TEXT NOT NULL,
 passenger_phone TEXT NOT NULL,
 pickup_address TEXT NOT NULL,
 destination_address TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','accepted','arrived','in_progress','completed','cancelled')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO settlements (name, slug) VALUES ('Стрелка','strelka') ON CONFLICT (slug) DO NOTHING;
