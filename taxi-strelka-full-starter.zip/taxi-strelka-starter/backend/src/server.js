import express from 'express';
import cors from 'cors';
import pg from 'pg';
const { Pool } = pg;
const app = express();
const pool = new Pool({connectionString: process.env.DATABASE_URL || 'postgres://taxi:taxi_dev_only@localhost:5432/taxi_strelka'});
const port = Number(process.env.PORT || 3000);
app.use(cors()); app.use(express.json({limit:'32kb'}));
app.get('/health', async (_req,res) => { try { await pool.query('SELECT 1'); res.json({ok:true,service:'taxi-strelka-api'}); } catch { res.status(503).json({ok:false,error:'database_unavailable'}); } });
app.get('/api/settlements', async (_req,res) => { try { res.json((await pool.query('SELECT id,name,slug FROM settlements ORDER BY name')).rows); } catch { res.status(500).json({error:'database_error'}); } });
app.get('/api/rides', async (_req,res) => { try { res.json((await pool.query(`SELECT r.id,s.name AS settlement,r.passenger_name AS "passengerName",r.passenger_phone AS "passengerPhone",r.pickup_address AS "pickupAddress",r.destination_address AS "destinationAddress",r.status,r.created_at AS "createdAt" FROM rides r JOIN settlements s ON s.id=r.settlement_id ORDER BY r.created_at DESC LIMIT 100`)).rows); } catch { res.status(500).json({error:'database_error'}); } });
app.post('/api/rides', async (req,res) => {
 const {settlementSlug='strelka',passengerName,passengerPhone,pickupAddress,destinationAddress}=req.body||{};
 const vals=[passengerName,passengerPhone,pickupAddress,destinationAddress];
 if(!vals.every(v=>typeof v==='string'&&v.trim().length>0)) return res.status(400).json({error:'Заполните имя, телефон, адрес подачи и адрес назначения.'});
 if(vals.some(v=>v.length>250)) return res.status(400).json({error:'Одно из полей слишком длинное.'});
 try { const s=await pool.query('SELECT id FROM settlements WHERE slug=$1',[settlementSlug]); if(!s.rowCount)return res.status(404).json({error:'Посёлок не найден.'});
 const result=await pool.query('INSERT INTO rides(settlement_id,passenger_name,passenger_phone,pickup_address,destination_address) VALUES($1,$2,$3,$4,$5) RETURNING id,status,created_at AS "createdAt"',[s.rows[0].id,...vals.map(v=>v.trim())]); return res.status(201).json(result.rows[0]);
 } catch { return res.status(500).json({error:'Не удалось создать заказ.'}); }
});
app.patch('/api/rides/:id/status', async (req,res) => { const allowed=['new','accepted','arrived','in_progress','completed','cancelled']; const {status}=req.body||{}; if(!allowed.includes(status))return res.status(400).json({error:'Недопустимый статус.'}); try { const r=await pool.query('UPDATE rides SET status=$1 WHERE id=$2 RETURNING id,status',[status,req.params.id]); if(!r.rowCount)return res.status(404).json({error:'Заказ не найден.'}); return res.json(r.rows[0]); } catch { return res.status(500).json({error:'Не удалось изменить статус.'}); } });
app.listen(port,'0.0.0.0',()=>console.log(`Такси Стрелка API слушает порт ${port}`));
